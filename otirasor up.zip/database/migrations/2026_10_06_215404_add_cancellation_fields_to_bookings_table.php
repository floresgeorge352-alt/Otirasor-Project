<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->timestamp('cancellation_requested_at')
                ->nullable()
                ->after('status');

            $table->string('cancellation_reason', 500)
                ->nullable()
                ->after('cancellation_requested_at');

            $table->string('cancellation_status')
                ->nullable()
                ->after('cancellation_reason');
        });
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn([
                'cancellation_requested_at',
                'cancellation_reason',
                'cancellation_status',
            ]);
        });
    }
};